﻿XVatsim Freeware
Version: 1.2.0
Platform: Windows / X-Plane 12 / xPilot

XVatsim is a freeware companion plugin for xPilot in X-Plane 12. It provides a clean, route-aware VATSIM frequency overlay focused on IFR flight-plan operations.

What XVatsim does:
- Shows relevant VATSIM frequencies for the current flight phase.
- Supports departure, enroute, and arrival frequency awareness.
- Displays COM1, COM2, TX, RX, MODE C, and Standby Assist state.
- Can recover the current flight after an xPilot disconnect/reconnect.
- Can manually check whether the installed XVatsim version is current.
- Can show CTAF or UNICOM fallback when controlled airport service is unavailable.

Install:
1. Close X-Plane 12.
2. Extract this zip file.
3. Copy the included Resources folder into your X-Plane 12 root folder.
4. Confirm this file exists:
   X-Plane 12\Resources\plugins\XVatsim\win_x64\XVatsim.xpl
5. Start X-Plane 12.
6. Start xPilot and connect to VATSIM.

Read XVatsim_User_Guide.pdf for complete setup, menu, keyboard-command, and troubleshooting instructions.

Support:
ezsimulations@gmail.com

For bug reports, include your callsign, route, what xPilot showed, what XVatsim showed, screenshots if possible, and these files:
- X-Plane 12\Resources\plugins\XVatsim\logs\xvatsim_diagnostics.log
- X-Plane 12\Log.txt

XVatsim is for home flight simulation only. It is not approved for real-world aviation, navigation, dispatch, flight planning, or air traffic control use.
